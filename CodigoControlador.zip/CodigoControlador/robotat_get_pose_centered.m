function pose_centered = robotat_get_pose_centered(tcp_obj, objetos)
    % --------------------------------------------------------------
    % Corrige posición (x, y, z) y orientación (yaw, pitch, roll)
    % del cubo respecto a una referencia medida.
    % Usa cuaterniones para evitar errores de acumulación o ambigüedad.
    % --------------------------------------------------------------

    % --- Pose de referencia del cubo (centrado y orientado) ---
    % [x y z yaw pitch roll]
    pose_ref = [0.0514, -0.0153, 0.0664, 227.7265, -30.6520, -0.2243];

    % --- Pose actual desde Robotat ---
    pose_actual = robotat_get_pose(tcp_obj, objetos, 'eulzyx');

    % --- Convertir orientación a cuaterniones (más estable que rotm) ---
    q_ref = quaternion(deg2rad(pose_ref(4:6)), 'eulerd', 'ZYX', 'frame');
    q_act = quaternion(deg2rad(pose_actual(4:6)), 'eulerd', 'ZYX', 'frame');

    % --- Calcular rotación relativa (de referencia → actual) ---
    % q_rel = q_ref⁻¹ * q_act
    q_rel = conj(q_ref) * q_act;

    % --- Convertir a ángulos Euler (ZYX) ---
    eul_rel = rad2deg(eulerd(q_rel, 'ZYX', 'frame'));
    eul_rel = wrapTo180(eul_rel);

    % --- Posición relativa en el marco de referencia del cubo ---
    R_ref = rotmat(q_ref, 'frame');
    pos_rel = (R_ref' * (pose_actual(1:3)' - pose_ref(1:3)'))';

    % --- Resultado final: [x y z yaw pitch roll] ---
    pose_centered = [pos_rel, eul_rel];
end
